<?php
// index.php - Entrada principal
session_start();


    // Si no está logueado, redirige a la página de inicio
    header("Location: paginas/index.php");

?>
