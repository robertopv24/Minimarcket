<?php
require_once '../templates/autoload.php';

session_start();
if (!isset($_SESSION['user_id']) || $userManager->getUserById($_SESSION['user_id'])['role'] !== 'admin') {
    header('Location: ../paginas/login.php');
    exit;
}

$productId = $_GET['id'] ?? null;
if (!$productId) {
    header('Location: productos.php');
    exit;
}

$producto = $productManager->getProductById($productId);
if (!$producto) {
    header('Location: productos.php');
    exit;
}

$mensaje = "";

// Procesar Formulario (JSON)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modifiers_json'])) {
    try {
        $data = json_decode($_POST['modifiers_json'], true);
        if ($productManager->saveProductExplodedDefaults($productId, $data)) {
            $mensaje = '<div class="alert alert-success">Configuración por defecto guardada correctamente.</div>';
        }
    } catch (Exception $e) {
        $mensaje = '<div class="alert alert-danger">Error: ' . $e->getMessage() . '</div>';
    }
}

// Determinar si es un combo (compound) para saber cómo "explotar" la vista
$isCombo = ($producto['product_type'] === 'compound');
$explodedComponents = [];

if (!$isCombo) {
    // Producto Individual (Simple o Preparado): Una sola tarjeta del producto mismo
    $explodedComponents[] = [
        'component_type' => 'product',
        'component_id' => $productId,
        'item_name' => $producto['name'],
        'quantity' => 1,
        'item_unit' => 'und'
    ];
} else {
    // Combo: Mostrar una tarjeta por cada unidad de cada producto integrante
    $components = $productManager->getProductComponents($productId);
    foreach ($components as $comp) {
        if ($comp['component_type'] !== 'product') continue; 
        $qty = intval($comp['quantity']);
        for ($i = 0; $i < $qty; $i++) {
            $explodedComponents[] = $comp;
        }
    }
}
$components = $explodedComponents;

// Obtener defaults actuales
$currentDefaultsRaw = $productManager->getProductExplodedDefaults($productId);
$currentDefaults = [
    'general_note' => '',
    'items' => []
];

foreach ($currentDefaultsRaw as $def) {
    $idx = $def['sub_item_index'];
    if ($idx == -1) {
        $currentDefaults['general_note'] = $def['note'];
        continue;
    }
    if (!isset($currentDefaults['items'][$idx])) {
        $currentDefaults['items'][$idx] = [
            'consumption' => ($def['is_takeaway'] == 1) ? 'takeaway' : 'dine_in',
            'remove' => [],
            'add' => [],
            'sides' => []
        ];
    }
    if ($def['modifier_type'] == 'remove') $currentDefaults['items'][$idx]['remove'][] = (int)$def['component_id'];
    if ($def['modifier_type'] == 'add') $currentDefaults['items'][$idx]['add'][] = (int)$def['component_id'];
    if ($def['modifier_type'] == 'side') $currentDefaults['items'][$idx]['sides'][] = (int)$def['component_id'];
}

// Obtener Acompañantes (Companions)
$companions = $productManager->getCompanions($productId);
$companionsCost = 0;
foreach ($companions as $comp) {
    // Usar costo de producción real del acompañante
    $childCost = $productManager->calculateProductCost($comp['companion_id']);
    $companionsCost += ($childCost * $comp['quantity']);
}

require_once '../templates/header.php';
require_once '../templates/menu.php';
?>

<div class="container-fluid mt-4" style="max-width: 1200px;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item"><a href="productos.php">Productos</a></li>
                    <li class="breadcrumb-item active">Configurar Defectos Advanced</li>
                </ol>
            </nav>
            <h2 class="fw-bold"><i class="fa fa-layer-group text-primary me-2"></i>Vista de Componentes: <?= htmlspecialchars($producto['name']) ?></h2>
            <p class="text-muted small mb-0">Define la configuración que tendrá el pedido por defecto al agregarlo al carrito.</p>
        </div>
        <div>
            <a href="productos.php" class="btn btn-outline-secondary me-2">Cancelar</a>
            <button type="button" onclick="submitDefaults()" class="btn btn-primary px-4 shadow">
                 <i class="fa fa-save me-1"></i> Guardar Todo
            </button>
        </div>
    </div>

    <?= $mensaje ?>

    <form id="defaultsForm" method="POST">
        <input type="hidden" name="modifiers_json" id="modifiers_json">
        
        <!-- Nota General -->
        <div class="card shadow-sm mb-4">
            <div class="card-body py-2">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light"><i class="fa fa-sticky-note me-2"></i> Nota Global por Defecto</span>
                    <input type="text" id="general_note" class="form-control" placeholder="Ej: Por favor bien caliente..." value="<?= htmlspecialchars($currentDefaults['general_note']) ?>">
                </div>
            </div>
        </div>

        <div class="row g-3" id="componentsContainer">
            <div class="col-md-8">
                <div class="row g-3">
                    <?php foreach ($components as $idx => $comp): 
                        $compId = $comp['component_id'];
                        $compType = $comp['component_type'];
                        
                        $validExtras = [];
                        $validSides = [];
                        $removableIngredients = [];
                        $maxSides = 0;

                        // Obtener costo base del componente (SIN contornos, ya que aquí se seleccionan manualmente)
                        $baseCompCost = 0;
                        $logic = 'standard';
                        $maxSides = 0;
                        if ($compType === 'product') {
                            $compBreakdown = $productManager->calculateProductCost($compId, 0, true);
                            $baseCompCost = $compBreakdown['recipe'] + $compBreakdown['packaging'];
                            
                            $validExtras = $productManager->getValidExtras($compId);
                            $validSides = $productManager->getValidSides($compId);
                            
                            $subCompData = $productManager->getProductById($compId);
                            $maxSides = $subCompData['max_sides'] ?? 0;
                            $logic = $subCompData['contour_logic_type'] ?? 'standard';
                            
                            if ($subCompData['product_type'] === 'prepared') {
                                $removableIngredients = $productManager->getProductComponents($compId);
                            }
                        }

                        $state = $currentDefaults['items'][$idx] ?? [
                            'consumption' => 'dine_in',
                            'remove' => [],
                            'add' => [],
                            'sides' => []
                        ];
                    ?>
                        <div class="col-md-12 col-lg-6">
                            <div class="card h-100 shadow-sm border-0 component-card" 
                                 data-idx="<?= $idx ?>" 
                                 data-base-cost="<?= $baseCompCost ?>"
                                 data-logic="<?= $logic ?>"
                                 data-max-sides="<?= $maxSides ?>">
                                <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center py-2">
                                    <span class="fw-bold small">#<?= $idx + 1 ?> <?= htmlspecialchars($comp['item_name']) ?></span>
                                    <div class="btn-group btn-group-sm rounded-pill overflow-hidden border border-secondary" role="group">
                                        <input type="radio" class="btn-check" name="cons_<?= $idx ?>" id="cons_dine_<?= $idx ?>" value="dine_in" <?= $state['consumption'] === 'dine_in' ? 'checked' : '' ?>>
                                        <label class="btn btn-outline-light py-0 px-2 border-0" for="cons_dine_<?= $idx ?>"><i class="fa fa-utensils" style="font-size: 0.8em;"></i></label>
                                        
                                        <input type="radio" class="btn-check" name="cons_<?= $idx ?>" id="cons_take_<?= $idx ?>" value="takeaway" <?= $state['consumption'] === 'takeaway' ? 'checked' : '' ?>>
                                        <label class="btn btn-outline-light py-0 px-2 border-0" for="cons_take_<?= $idx ?>"><i class="fa fa-shopping-bag" style="font-size: 0.8em;"></i></label>
                                    </div>
                                </div>
                                <div class="card-body p-3 overflow-auto" style="max-height: 400px;">
                                    
                                    <!-- REMOCIONES -->
                                    <?php if (!empty($removableIngredients)): ?>
                                        <label class="fw-bold text-danger small mb-2"><i class="fa fa-minus-circle"></i> Quitar por Defecto:</label>
                                        <div class="mb-3 ps-2">
                                            <?php foreach ($removableIngredients as $ring): 
                                                if ($ring['component_type'] !== 'raw') continue;
                                                $isRemoved = in_array($ring['component_id'], $state['remove']);
                                                $ringCost = floatval($ring['item_cost'] * $ring['quantity']);
                                            ?>
                                                <div class="form-check mb-1">
                                                    <input class="form-check-input remove-chk border-danger" type="checkbox" value="<?= $ring['component_id'] ?>" 
                                                            data-idx="<?= $idx ?>" data-cost="<?= $ringCost ?>" <?= $isRemoved ? 'checked' : '' ?> onchange="updateTotalCostUI()">
                                                    <label class="form-check-label small text-muted">Quitar <?= htmlspecialchars($ring['item_name']) ?></label>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- EXTRAS -->
                                    <?php if (!empty($validExtras)): ?>
                                        <label class="fw-bold text-success small mb-2"><i class="fa fa-plus-circle"></i> Extras Incluidos:</label>
                                        <div class="mb-3 ps-2">
                                            <?php foreach ($validExtras as $extra): 
                                                $isSelected = in_array($extra['component_id'], $state['add']);
                                                $extraCost = floatval($extra['cost_per_unit'] * $extra['quantity_required']);
                                            ?>
                                                <div class="form-check mb-1">
                                                    <input class="form-check-input add-chk border-success" type="checkbox" value="<?= $extra['component_id'] ?>" 
                                                        data-type="<?= $extra['component_type'] ?>" data-qty="<?= $extra['quantity_required'] ?>" data-price="<?= $extra['price_override'] ?>"
                                                        data-cost="<?= $extraCost ?>" data-idx="<?= $idx ?>" <?= $isSelected ? 'checked' : '' ?> onchange="updateTotalCostUI()">
                                                    <label class="form-check-label small d-flex justify-content-between pe-2 w-100">
                                                        <span><?= htmlspecialchars($extra['name']) ?></span>
                                                        <span class="text-success small">+$<?= number_format($extra['price_override'], 2) ?></span>
                                                    </label>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- CONTORNOS -->
                                    <?php if (!empty($validSides)): ?>
                                        <label class="fw-bold text-info small mb-2"><i class="fa fa-utensils"></i> Contornos Seleccionados:</label>
                                        <div class="mb-3 ps-2">
                                            <small class="text-muted d-block mb-1">(Límite: <?= $maxSides ?>)</small>
                                            <?php foreach ($validSides as $side): 
                                                $isSelected = in_array($side['component_id'], $state['sides']);
                                                $sideCost = floatval(($side['item_cost'] ?? 0) * $side['quantity']);
                                            ?>
                                                <div class="form-check mb-1">
                                                    <input class="form-check-input side-chk border-info" type="checkbox" value="<?= $side['component_id'] ?>" 
                                                        data-type="<?= $side['component_type'] ?>" data-qty="<?= $side['quantity'] ?>" data-price="<?= $side['price_override'] ?>"
                                                        data-cost="<?= $sideCost ?>" data-idx="<?= $idx ?>" <?= $isSelected ? 'checked' : '' ?> onchange="updateTotalCostUI()">
                                                    <label class="form-check-label small d-flex justify-content-between pe-2 w-100">
                                                        <span><?= htmlspecialchars($side['item_name']) ?></span>
                                                        <span class="text-info small">+$<?= number_format($side['price_override'], 2) ?></span>
                                                    </label>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php if (empty($removableIngredients) && empty($validExtras) && empty($validSides)): ?>
                                        <div class="text-center py-4 text-muted small">
                                            <i class="fa fa-info-circle fa-2x mb-2 opacity-25"></i><br>
                                            Este componente no tiene opciones personalizables.
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if (!empty($companions)): ?>
                <div class="card shadow-sm border-0 border-start border-4 border-primary mt-4">
                    <div class="card-body">
                        <h5 class="card-title text-primary fw-bold"><i class="fa fa-handshake me-2"></i> Acompañantes Automáticos</h5>
                        <p class="text-muted small mb-2">Estos productos se agregarán automáticamente al carrito junto con este producto.</p>
                        <div class="table-responsive">
                            <table class="table table-sm table-borderless mb-0">
                                <thead class="text-secondary small">
                                    <tr>
                                        <th>Producto</th>
                                        <th>Cantidad</th>
                                        <th>Costo Extra</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($companions as $comp): 
                                        $price = ($comp['price_override'] !== null) ? $comp['price_override'] : $comp['base_price'];
                                        $total = $price * $comp['quantity'];
                                    ?>
                                        <tr>
                                            <td class="fw-bold"><?= htmlspecialchars($comp['name']) ?></td>
                                            <td><?= floatval($comp['quantity']) ?></td>
                                            <td class="text-success fw-bold">+$<?= number_format($total, 2) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Analizador de Costos -->
            <div class="col-md-4">
                <div class="card shadow border-primary sticky-top" style="top: 20px; z-index: 1020;">
                    <div class="card-header bg-primary text-white py-3">
                        <h5 class="mb-0"><i class="fa fa-calculator me-2"></i> Análisis de Costo Base</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Producción Original:</span>
                            <span class="fw-bold" id="cost_original">$0.00</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2 text-success">
                            <span>(+) Extras por Defecto:</span>
                            <span class="fw-bold" id="cost_extras">$0.00</span>
                        </div>
                        <?php if ($companionsCost > 0): ?>
                        <div class="d-flex justify-content-between mb-2 text-primary">
                            <span>(+) Acompañantes:</span>
                            <span class="fw-bold fw-extra">$<?= number_format($companionsCost, 2) ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between mb-2 text-info">
                            <span>(+) Contornos/Lados:</span>
                            <span class="fw-bold" id="cost_sides">$0.00</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2 text-danger">
                            <span>(-) Ahorro Remociones:</span>
                            <span class="fw-bold" id="cost_removals">-$0.00</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="mb-0">Costo Final:</h4>
                            <h3 class="text-primary fw-bold mb-0" id="cost_total">$0.00</h3>
                        </div>
                        <p class="text-muted small mt-3">
                            <i class="fa fa-info-circle"></i> Este es el costo estimado de <strong>producción</strong> 
                            bajo esta configuración. Se calcula sumando el costo de cada ingrediente del inventario.
                        </p>
                    </div>
                    <div class="card-footer bg-light p-0">
                        <button type="button" onclick="submitDefaults()" class="btn btn-primary btn-lg w-100 rounded-0 py-3 fw-bold">
                            <i class="fa fa-save me-2"></i> GUARDAR CONFIGURACIÓN
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<style>
    .component-card { transition: transform 0.2s, box-shadow 0.2s; border: 1px solid #eee !important; }
    .component-card:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.1) !important; border-color: #0d6efd !important; }
    .btn-check:checked + label { background-color: #fff !important; color: #212529 !important; font-weight: bold; }
    .card-body::-webkit-scrollbar { width: 5px; }
    .card-body::-webkit-scrollbar-track { background: #f1f1f1; }
    .card-body::-webkit-scrollbar-thumb { background: #ccc; border-radius: 10px; }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const sideCheckboxes = document.querySelectorAll('.side-chk');
        
        function validateMaxSides(idx) {
            const card = document.querySelector(`.component-card[data-idx="${idx}"]`);
            if (!card) return;
            
            const chks = card.querySelectorAll('.side-chk');
            if (chks.length === 0) return;
            
            const max = parseInt(card.dataset.maxSides || 0);
            const checkedCount = Array.from(chks).filter(cb => cb.checked).length;
            
            chks.forEach(cb => {
                if (!cb.checked && checkedCount >= max) {
                    cb.disabled = true;
                } else {
                    cb.disabled = false;
                }
            });
        }

        // Inicializar validación para cada tarjeta
        const cards = document.querySelectorAll('.component-card');
        cards.forEach(card => validateMaxSides(card.dataset.idx));

        // Listener para cambios
        sideCheckboxes.forEach(cb => {
            cb.addEventListener('change', function() {
                validateMaxSides(this.dataset.idx);
            });
        });

        updateTotalCostUI(); // Cálculo inicial
    });

    function updateTotalCostUI() {
        let originalCost = 0;
        let extrasCost = 0;
        let sidesCost = 0;
        let removalsSaving = 0;
        let hasProportional = false;

        document.querySelectorAll('.component-card').forEach(card => {
            const logic = card.dataset.logic;
            const maxSides = parseInt(card.dataset.maxSides || 0);

            // 1. Base
            originalCost += parseFloat(card.dataset.baseCost || 0);

            // 2. Extras (Add-ons)
            card.querySelectorAll('.add-chk:checked').forEach(chk => {
                extrasCost += parseFloat(chk.dataset.cost || 0);
            });

            // 3. Contornos (Sides)
            let selectedSides = card.querySelectorAll('.side-chk:checked');
            let cardSidesRawCost = 0;
            selectedSides.forEach(chk => {
                cardSidesRawCost += parseFloat(chk.dataset.cost || 0);
            });

            if (logic === 'proportional' && selectedSides.length > 0) {
                // Si es proporcional, dividimos el costo total de los contornos entre el máximo permitido
                sidesCost += (cardSidesRawCost / maxSides);
                hasProportional = true;
            } else {
                sidesCost += cardSidesRawCost;
            }

            // 4. Remociones (Ahorro)
            card.querySelectorAll('.remove-chk:checked').forEach(chk => {
                removalsSaving += parseFloat(chk.dataset.cost || 0);
            });
        });

        const companionsCost = <?= floatval($companionsCost) ?>;
        const totalFinal = (originalCost + extrasCost + sidesCost + companionsCost) - removalsSaving;

        // Actualizar UI
        document.getElementById('cost_original').innerText = `$${originalCost.toFixed(2)}`;
        document.getElementById('cost_extras').innerText = `+$${extrasCost.toFixed(2)}`;
        
        // Mostrar costo de acompañantes si existe
        if (companionsCost > 0) {
            let compElem = document.getElementById('cost_companions');
            if (!compElem) {
                // Si no existe el elemento, lo creamos dinamicamente (fallback) o asumimos que ya existe en el HTML
                   // Mejor estrategia: Insertar el elemento en el HTML también
            }
        }
        document.getElementById('cost_extras').innerText = `+$${extrasCost.toFixed(2)}`;

        let sidesText = `+$${sidesCost.toFixed(2)}`;
        if (hasProportional) {
            sidesText += ' <small class="badge bg-info text-dark" style="font-size:0.6em">PROP.</small>';
        }
        document.getElementById('cost_sides').innerHTML = sidesText;

        document.getElementById('cost_removals').innerText = `-$${removalsSaving.toFixed(2)}`;
        document.getElementById('cost_total').innerText = `$${totalFinal.toFixed(2)}`;
    }

    function submitDefaults() {
        const items = [];
        const cards = document.querySelectorAll('.component-card');
        const generalNote = document.getElementById('general_note').value;

        cards.forEach(card => {
            const idx = card.dataset.idx;
            const consumption = document.querySelector(`input[name="cons_${idx}"]:checked`).value;
            
            const remove = [];
            const add = [];
            const sides = [];

            card.querySelectorAll('.remove-chk:checked').forEach(el => remove.push(parseInt(el.value)));
            card.querySelectorAll('.add-chk:checked').forEach(el => add.push({
                id: parseInt(el.value),
                type: el.dataset.type,
                qty: parseFloat(el.dataset.qty),
                price: parseFloat(el.dataset.price)
            }));
            card.querySelectorAll('.side-chk:checked').forEach(el => sides.push({
                id: parseInt(el.value),
                type: el.dataset.type,
                qty: parseFloat(el.dataset.qty),
                price: parseFloat(el.dataset.price)
            }));

            items.push({
                index: parseInt(idx),
                consumption: consumption,
                remove: remove,
                add: add,
                sides: sides
            });
        });

        const finalData = {
            general_note: generalNote,
            items: items
        };

        document.getElementById('modifiers_json').value = JSON.stringify(finalData);
        document.getElementById('defaultsForm').submit();
    }
</script>

<?php require_once '../templates/footer.php'; ?>
