<?php

require_once __DIR__ . '/conexion.php';

class ProductManager
{
    private $db;
    private $costCache = [];

    public function __construct($db = null)
    {
        $this->db = $db ?: Database::getConnection();
    }

    // Crear un producto con márgenes de ganancia
    public function createProduct($name, $description, $price_usd, $price_ves, $stock, $image_url = 'default.jpg', $profit_margin = 20.00, $min_stock = 5, $category_id = null, $is_visible = 1)
    {
        $stmt = $this->db->prepare("INSERT INTO products (name, description, price_usd, price_ves, stock, image_url, profit_margin, min_stock, category_id, is_visible, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        return $stmt->execute([$name, $description, $price_usd, $price_ves, $stock, $image_url, $profit_margin, $min_stock, $category_id, $is_visible]);
    }

    // Obtener un producto por ID
    public function getProductById($id)
    {
        $stmt = $this->db->prepare("SELECT p.*, c.name as category_name, c.kitchen_station as category_station 
                                    FROM products p 
                                    LEFT JOIN categories c ON p.category_id = c.id 
                                    WHERE p.id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function getTotalProduct()
    {
        $query = "SELECT COUNT(*) AS total FROM products";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ?? 0;
    }

    public function updateProductPriceVes($productId, $newPriceVes)
    {
        $stmt = $this->db->prepare("UPDATE products SET price_ves = ? WHERE id = ?");
        return $stmt->execute([$newPriceVes, $productId]);
    }

    // Obtener todos los productos (Opcionalmente filtrados por categoría y visibilidad)
    public function getAllProducts($categoryId = null, $onlyVisible = false)
    {
        $sql = "SELECT p.*, c.name as category_name FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id";

        $where = [];
        $params = [];

        if ($categoryId) {
            $where[] = "p.category_id = ?";
            $params[] = $categoryId;
        }

        if ($onlyVisible) {
            $where[] = "p.is_visible = 1";
        }

        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }

        $sql .= " ORDER BY p.created_at DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Buscar productos por nombre (Opcionalmente dentro de una categoría y visibilidad)
    public function searchProducts($keyword, $categoryId = null, $onlyVisible = false)
    {
        $sql = "SELECT p.*, c.name as category_name FROM products p 
                LEFT JOIN categories c ON p.category_id = c.id 
                WHERE p.name LIKE ?";

        $params = ["%$keyword%"];

        if ($categoryId) {
            $sql .= " AND p.category_id = ?";
            $params[] = $categoryId;
        }

        if ($onlyVisible) {
            $sql .= " AND p.is_visible = 1";
        }

        $sql .= " ORDER BY p.created_at DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener productos con stock disponible
    public function getAvailableProducts()
    {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE stock > 0 ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener productos con stock bajo (Dinámico según min_stock)
    public function getLowStockProducts()
    {
        $lowStock = [];

        // A. Productos SIMPLE (Reventa) - Validación directa SQL
        $stmtEx = $this->db->query("SELECT * FROM products WHERE product_type = 'simple' AND stock < min_stock");
        $simpleLow = $stmtEx->fetchAll(PDO::FETCH_ASSOC);
        foreach ($simpleLow as $s) {
            $s['stock_source'] = 'physical';
            $lowStock[] = $s;
        }

        // B. Productos PREPARED/COMPOUND (Cocina/Combos) - Validación Virtual
        $stmtPrep = $this->db->query("SELECT * FROM products WHERE product_type IN ('prepared', 'compound')");
        $prepared = $stmtPrep->fetchAll(PDO::FETCH_ASSOC);

        foreach ($prepared as $p) {
            $analysis = $this->getVirtualStockAnalysis($p['id']);
            $virtualStock = $analysis['max_produceable'];
            $minStock = floatval($p['min_stock']);

            if ($virtualStock < $minStock) {
                // Sobrescribir 'stock' visualmente para que el dashboard muestre la realidad disponible
                $p['stock'] = $virtualStock;
                $p['stock_source'] = 'virtual';
                $p['limiting_component'] = $analysis['limiting_component'];
                $lowStock[] = $p;
            }
        }

        return $lowStock;
    }

    // Actualizar un producto
    public function updateProduct($id, $name, $description, $price_usd, $price_ves, $stock, $image = null, $profit_margin = 20.00, $min_stock = 5, $category_id = null, $is_visible = 1, $kitchen_station = null)
    {
        if ($image) {
            $stmt = $this->db->prepare("UPDATE products SET name = ?, description = ?, price_usd = ?, price_ves = ?, stock = ?, image_url = ?, profit_margin = ?, min_stock = ?, category_id = ?, is_visible = ?, kitchen_station = ?, updated_at = NOW() WHERE id = ?");
            return $stmt->execute([$name, $description, $price_usd, $price_ves, $stock, $image, $profit_margin, $min_stock, $category_id, $is_visible, $kitchen_station, $id]);
        } else {
            $stmt = $this->db->prepare("UPDATE products SET name = ?, description = ?, price_usd = ?, price_ves = ?, stock = ?, profit_margin = ?, min_stock = ?, category_id = ?, is_visible = ?, kitchen_station = ?, updated_at = NOW() WHERE id = ?");
            return $stmt->execute([$name, $description, $price_usd, $price_ves, $stock, $profit_margin, $min_stock, $category_id, $is_visible, $kitchen_station, $id]);
        }
    }

    // Actualizar stock de un producto
    public function updateProductStock($id, $stock)
    {
        $stmt = $this->db->prepare("UPDATE products SET stock = ?, created_at = NOW() WHERE id = ?");
        return $stmt->execute([$stock, $id]);
    }

    // Eliminar un producto
    public function deleteProduct($id)
    {
        $stmt = $this->db->prepare("DELETE FROM products WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function updateAllPricesBasedOnRate($newRate)
    {
        try {
            $sql = "UPDATE products SET price_ves = price_usd * :rate, updated_at = NOW()";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([':rate' => $newRate]);
        } catch (PDOException $e) {
            error_log("Error en actualización masiva: " . $e->getMessage());
            return false;
        }
    }

    // --- NUEVAS FUNCIONES PARA MANEJO DE RECETAS DE VENTA ---

    public function updateProductType($id, $type)
    {
        $stmt = $this->db->prepare("UPDATE products SET product_type = ? WHERE id = ?");
        return $stmt->execute([$type, $id]);
    }

    public function getProductComponents($productId, $depth = 0)
    {
        $sql = "SELECT pc.*,
                CASE
                    WHEN pc.component_type = 'raw' THEN rm.name
                    WHEN pc.component_type = 'manufactured' THEN mp.name
                    WHEN pc.component_type = 'product' THEN p.name
                END as item_name,
                CASE
                    WHEN pc.component_type = 'raw' THEN rm.unit
                    WHEN pc.component_type = 'manufactured' THEN mp.unit
                    WHEN pc.component_type = 'product' THEN 'und'
                END as item_unit,
                CASE
                    WHEN pc.component_type = 'raw' THEN rm.cost_per_unit
                    WHEN pc.component_type = 'manufactured' THEN mp.unit_cost_average
                    WHEN pc.component_type = 'product' THEN p.price_usd
                END as item_cost,
                CASE
                    WHEN pc.component_type = 'raw' THEN rm.short_code
                    WHEN pc.component_type = 'manufactured' THEN mp.short_code
                    WHEN pc.component_type = 'product' THEN p.short_code
                END as short_code,
                CASE
                    WHEN pc.component_type = 'raw' THEN rm.category
                    ELSE NULL
                END as item_category,
                cat.name as category_name,
                cat.kitchen_station as category_station
                FROM product_components pc
                LEFT JOIN raw_materials rm ON pc.component_id = rm.id AND pc.component_type = 'raw'
                LEFT JOIN manufactured_products mp ON pc.component_id = mp.id AND pc.component_type = 'manufactured'
                LEFT JOIN products p ON pc.component_id = p.id AND pc.component_type = 'product'
                LEFT JOIN categories cat ON p.category_id = cat.id AND pc.component_type = 'product'
                WHERE pc.product_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$productId]);
        $components = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // FIX: Para componentes de tipo 'product', calcular su costo real recursivamente
        foreach ($components as &$comp) {
            // Cargar Overrides si existen
            $comp['overrides'] = $this->getComponentOverrides($comp['id']);
            $comp['has_overrides'] = !empty($comp['overrides']);

            if ($comp['component_type'] == 'product' && $comp['component_id']) {
                $comp['item_cost'] = $this->calculateProductCost($comp['component_id'], $depth + 1, false, $comp['id']);
            }
        }

        return $components;
    }

    /**
     * Obtener ingredientes personalizados de un componente dentro de un combo
     */
    public function getComponentOverrides($componentRowId)
    {
        $sql = "SELECT pco.*,
                pco.ingredient_type as component_type,
                pco.ingredient_id as component_id,
                CASE
                    WHEN pco.ingredient_type = 'raw' THEN rm.name
                    WHEN pco.ingredient_type = 'manufactured' THEN mp.name
                    WHEN pco.ingredient_type = 'product' THEN p.name
                END as item_name,
                CASE
                    WHEN pco.ingredient_type = 'raw' THEN rm.unit
                    WHEN pco.ingredient_type = 'manufactured' THEN mp.unit
                    WHEN pco.ingredient_type = 'product' THEN 'und'
                END as item_unit,
                CASE
                    WHEN pco.ingredient_type = 'raw' THEN rm.cost_per_unit
                    WHEN pco.ingredient_type = 'manufactured' THEN mp.unit_cost_average
                    WHEN pco.ingredient_type = 'product' THEN p.price_usd
                END as item_cost
                FROM product_component_overrides pco
                LEFT JOIN raw_materials rm ON pco.ingredient_id = rm.id AND pco.ingredient_type = 'raw'
                LEFT JOIN manufactured_products mp ON pco.ingredient_id = mp.id AND pco.ingredient_type = 'manufactured'
                LEFT JOIN products p ON pco.ingredient_id = p.id AND pco.ingredient_type = 'product'
                WHERE pco.component_row_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$componentRowId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Guardar receta personalizada para un componente de combo
     */
    public function updateComponentOverrides($componentRowId, $ingredients)
    {
        try {
            $this->db->beginTransaction();

            // 1. Borrar configuración anterior
            $stmtDel = $this->db->prepare("DELETE FROM product_component_overrides WHERE component_row_id = ?");
            $stmtDel->execute([$componentRowId]);

            // 2. Insertar nuevos ingredientes
            if (!empty($ingredients)) {
                $stmtIns = $this->db->prepare("INSERT INTO product_component_overrides (component_row_id, ingredient_type, ingredient_id, quantity) VALUES (?, ?, ?, ?)");
                foreach ($ingredients as $ing) {
                    $stmtIns->execute([
                        $componentRowId,
                        $ing['type'],
                        $ing['id'],
                        $ing['qty']
                    ]);
                }
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error en updateComponentOverrides: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Obtener contornos personalizados de un componente dentro de un combo
     */
    public function getComponentSideOverrides($componentRowId)
    {
        $sql = "SELECT pcso.*,
                pcso.side_type as component_type,
                pcso.side_id as component_id,
                CASE
                    WHEN pcso.side_type = 'raw' THEN rm.name
                    WHEN pcso.side_type = 'manufactured' THEN mp.name
                    WHEN pcso.side_type = 'product' THEN p.name
                END as item_name,
                CASE
                    WHEN pcso.side_type = 'raw' THEN rm.unit
                    WHEN pcso.side_type = 'manufactured' THEN mp.unit
                    WHEN pcso.side_type = 'product' THEN 'und'
                END as item_unit,
                CASE
                    WHEN pcso.side_type = 'raw' THEN rm.cost_per_unit
                    WHEN pcso.side_type = 'manufactured' THEN mp.unit_cost_average
                    WHEN pcso.side_type = 'product' THEN p.price_usd
                END as item_cost
                FROM product_component_side_overrides pcso
                LEFT JOIN raw_materials rm ON pcso.side_id = rm.id AND pcso.side_type = 'raw'
                LEFT JOIN manufactured_products mp ON pcso.side_id = mp.id AND pcso.side_type = 'manufactured'
                LEFT JOIN products p ON pcso.side_id = p.id AND pcso.side_type = 'product'
                WHERE pcso.component_row_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$componentRowId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Guardar contornos personalizados para un componente de combo
     */
    public function updateComponentSideOverrides($componentRowId, $sides)
    {
        try {
            $this->db->beginTransaction();

            // 1. Borrar configuración anterior
            $stmtDel = $this->db->prepare("DELETE FROM product_component_side_overrides WHERE component_row_id = ?");
            $stmtDel->execute([$componentRowId]);

            // 2. Insertar nuevos contornos
            if (!empty($sides)) {
                $stmtIns = $this->db->prepare("INSERT INTO product_component_side_overrides (component_row_id, side_type, side_id, quantity, is_default) VALUES (?, ?, ?, ?, ?)");
                foreach ($sides as $s) {
                    $stmtIns->execute([
                        $componentRowId,
                        $s['type'],
                        $s['id'],
                        $s['qty'],
                        isset($s['is_default']) ? $s['is_default'] : 0
                    ]);
                }
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error en updateComponentSideOverrides: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Calcula el costo de producción real de un producto sumando recursivamente
     * los costos de sus componentes (evita usar precio de venta)
     */
    public function calculateProductCost($productId, $depth = 0, $returnBreakdown = false, $overrideRowId = null)
    {
        if ($depth > 10)
            return 0; // Prevent Infinite loop

        // Use cache only for top-level call to avoid complexity with depth
        if ($depth === 0 && !$returnBreakdown && isset($this->costCache[$productId])) {
            return $this->costCache[$productId];
        }

        $components = $this->getProductComponents($productId, $depth);
        $product = $this->getProductById($productId);
        if (!$product)
            return 0;

        $totalCost = 0;
        $breakdown = [
            'recipe' => 0,
            'sides' => 0,
            'packaging' => 0,
            'companions' => 0,
            'total' => 0
        ];

        $hasRecipe = !empty($components);

        // A. COSTO DE COMPONENTES BASE
        if ($overrideRowId) {
            // USAR RECETA PERSONALIZADA SI EXISTE
            $overrides = $this->getComponentOverrides($overrideRowId);
            if (!empty($overrides)) {
                foreach ($overrides as $ov) {
                    $ovCost = floatval($ov['item_cost'] ?? 0);
                    $totalCost += ($ov['quantity'] * $ovCost);
                }
                $hasRecipe = true;
            }
        }

        if ($totalCost == 0) { // Si no hubo overrides o no devolvieron costo
            if ($hasRecipe) {
                foreach ($components as $comp) {
                    $itemCost = floatval($comp['item_cost'] ?? 0);
                    $totalCost += ($comp['quantity'] * $itemCost);
                }
            } elseif ($product['product_type'] === 'simple') {
                // SOLO Para producto de REVENTA (ej: refrescos, snacks) calculamos costo virtual basado en margen
                $price = floatval($product['price_usd'] ?? 0);
                $margin = floatval($product['profit_margin'] ?? 20);
                $totalCost = $price * (1 - ($margin / 100));
            } else {
                // SI ES PREPARED O COMPOUND Y NO TIENE RECETA, COSTO BASE ES 0
                $totalCost = 0;
            }
        }
        $breakdown['recipe'] = $totalCost;

        // B. COSTO ESTIMADO DE CONTORNOS (SIDES)
        // Si el producto permite contornos, su "costo real" de venta debe incluirlos
        $maxSides = intval($product['max_sides'] ?? 0);
        $logic = $product['contour_logic_type'] ?? 'standard';

        $sidesCost = 0;
        if ($maxSides > 0) {
            // AJUSTE: Usar contornos personalizados si existe override context
            $validSides = [];
            if ($overrideRowId) {
                $validSides = $this->getComponentSideOverrides($overrideRowId);
            }

            if (empty($validSides)) {
                $validSides = $this->getValidSides($productId);
            }

            if (!empty($validSides)) {
                $sumSideCosts = 0;
                foreach ($validSides as $side) {
                    $sideCost = 0;
                    if ($side['component_type'] == 'raw') {
                        $s = $this->db->prepare("SELECT cost_per_unit FROM raw_materials WHERE id = ?");
                        $s->execute([$side['component_id']]);
                        $sideCost = floatval($s->fetchColumn());
                    } elseif ($side['component_type'] == 'manufactured') {
                        $s = $this->db->prepare("SELECT unit_cost_average FROM manufactured_products WHERE id = ?");
                        $s->execute([$side['component_id']]);
                        $sideCost = floatval($s->fetchColumn());
                    } elseif ($side['component_type'] == 'product') {
                        // RECURSIVIDAD: Si el contorno es otro producto, calculamos su costo real
                        $sideCost = $this->calculateProductCost($side['component_id'], $depth + 1);
                    }
                    $sumSideCosts += ($sideCost * floatval($side['quantity']));
                }

                $avgSideCost = $sumSideCosts / count($validSides);

                // AJUSTE: Si es estándar, el cliente consume N porciones completas.
                // Si es proporcional, el cliente consume N sub-porciones que suman 1 porción completa.
                if ($logic === 'standard') {
                    $sidesCost = ($avgSideCost * $maxSides);
                } else {
                    $sidesCost = $avgSideCost;
                }
                $totalCost += $sidesCost;
            }
        }
        $breakdown['sides'] = $sidesCost;

        // C. COSTO DE EMPAQUE (PACKAGING)
        $packagingCost = 0;
        $packaging = $this->getProductPackaging($productId);
        if (!empty($packaging)) {
            foreach ($packaging as $pack) {
                // El packaging siempre suma su costo directo
                $packagingCost += (floatval($pack['quantity']) * floatval($pack['cost_per_unit'] ?? 0));
            }
        }
        $totalCost += $packagingCost;
        $breakdown['packaging'] = $packagingCost;

        // D. COSTO DE ACOMPAÑANTES (COMPANIONS) - NUEVO
        $companionsCost = 0;
        $companions = $this->getCompanions($productId);
        if (!empty($companions)) {
            foreach ($companions as $comp) {
                // Un acompañante es un producto, calculamos su costo recursivamente (depth + 1)
                $childCost = $this->calculateProductCost($comp['companion_id'], $depth + 1);
                $companionsCost += ($childCost * floatval($comp['quantity']));
            }
        }
        $totalCost += $companionsCost;
        $breakdown['companions'] = $companionsCost;

        $breakdown['total'] = $totalCost;

        if ($depth === 0) {
            $this->costCache[$productId] = $totalCost;
        }

        return $returnBreakdown ? $breakdown : $totalCost;
    }

    public function addComponent($productId, $type, $componentId, $qty)
    {
        $sqlCheck = "SELECT id FROM product_components WHERE product_id = ? AND component_type = ? AND component_id = ?";
        $stmtCheck = $this->db->prepare($sqlCheck);
        $stmtCheck->execute([$productId, $type, $componentId]);

        if ($stmtCheck->fetch()) {
            $sql = "UPDATE product_components SET quantity = quantity + ? WHERE product_id = ? AND component_type = ? AND component_id = ?";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$qty, $productId, $type, $componentId]);
        } else {
            $sql = "INSERT INTO product_components (product_id, component_type, component_id, quantity) VALUES (?, ?, ?, ?)";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$productId, $type, $componentId, $qty]);
        }
    }

    public function updateComponentQuantity($rowId, $newQuantity)
    {
        $stmt = $this->db->prepare("UPDATE product_components SET quantity = ? WHERE id = ?");
        return $stmt->execute([$newQuantity, $rowId]);
    }

    public function removeComponent($id)
    {
        $stmt = $this->db->prepare("DELETE FROM product_components WHERE id = ?");
        return $stmt->execute([$id]);
    }

    // =========================================================
    // CÁLCULO DE STOCK POTENCIAL (RECURSIVO)
    // =========================================================

    public function getVirtualStock($productId, $depth = 0)
    {
        $analysis = $this->getVirtualStockAnalysis($productId, $depth);
        return $analysis['max_produceable'];
    }

    public function getVirtualStockAnalysis($productId, $depth = 0)
    {
        if ($depth > 10)
            return ['max_produceable' => 0, 'limiting_component' => null];

        // 1. OBTENER CONFIGURACIÓN DEL PRODUCTO
        $productData = $this->getProductById($productId);
        if (!$productData)
            return ['max_produceable' => 0, 'limiting_component' => null];

        // SI ES SIMPLE, SU STOCK VIRTUAL ES SU STOCK FÍSICO (Para que los combos lo vean)
        if ($productData['product_type'] === 'simple') {
            return ['max_produceable' => floatval($productData['stock']), 'limiting_component' => null];
        }

        $isPrepared = ($productData['product_type'] === 'prepared' || $productData['product_type'] === 'compound');
        $maxSides = intval($productData['max_sides'] ?? 0);
        $logic = $productData['contour_logic_type'] ?? 'standard';

        // 2. COMPONENTES BASE (RECETA FIJA)
        $components = $this->getProductComponents($productId, $depth);

        $minProduceable = null;
        $limitingComponent = null;

        if (!empty($components)) {
            foreach ($components as $comp) {
                $qtyNeeded = floatval($comp['quantity']);
                if ($qtyNeeded <= 0)
                    continue;

                $currentStock = 0;
                $itemName = 'Componente';
                $itemUnit = 'Und';

                if ($comp['component_type'] == 'raw') {
                    $stmt = $this->db->prepare("SELECT name, stock_quantity, unit FROM raw_materials WHERE id = ?");
                    $stmt->execute([$comp['component_id']]);
                    $data = $stmt->fetch(PDO::FETCH_ASSOC);
                    $currentStock = floatval($data['stock_quantity'] ?? 0);
                    $itemName = $data['name'] ?? 'Insumo';
                    $itemUnit = $data['unit'] ?? 'Und';
                } elseif ($comp['component_type'] == 'manufactured') {
                    $stmt = $this->db->prepare("SELECT name, stock, unit FROM manufactured_products WHERE id = ?");
                    $stmt->execute([$comp['component_id']]);
                    $data = $stmt->fetch(PDO::FETCH_ASSOC);
                    $currentStock = floatval($data['stock'] ?? 0);
                    $itemName = $data['name'] ?? 'Manufacturado';
                    $itemUnit = $data['unit'] ?? 'Und';
                } elseif ($comp['component_type'] == 'product') {
                    $subAnalysis = $this->getVirtualStockAnalysis($comp['component_id'], $depth + 1);
                    $currentStock = $subAnalysis['max_produceable'];
                    $itemName = $comp['item_name'] ?? 'Producto';
                }

                $possibleWithThisItem = floor($currentStock / $qtyNeeded);
                if ($minProduceable === null || $possibleWithThisItem < $minProduceable) {
                    $minProduceable = $possibleWithThisItem;
                    $limitingComponent = [
                        'name' => $itemName,
                        'available' => $currentStock,
                        'unit' => $itemUnit,
                        'required_per_unit' => $qtyNeeded
                    ];
                }
            }
        }

        // 3. ANÁLISIS DE CONTORNOS (SIDES)
        // Solo si el producto requiere contornos (max_sides > 0)
        if ($maxSides > 0) {
            $validSides = $this->getValidSides($productId);
            if (!empty($validSides)) {
                $totalSidesAvailability = 0;
                $bestSideName = "";

                foreach ($validSides as $side) {
                    $sideQty = floatval($side['quantity']);
                    if ($sideQty <= 0)
                        continue;

                    // Ajustar cantidad requerida si la lógica es proporcional
                    // Si el cliente elige N contornos, cada uno gasta Q/N.
                    // Para el stock virtual (capacidad total), consideramos que el cliente gasta 
                    // la porción configurada dividida entre el máximo permitido.
                    $effectiveQty = ($logic === 'proportional') ? ($sideQty / $maxSides) : $sideQty;

                    $stock = 0;
                    if ($side['component_type'] == 'raw') {
                        $s = $this->db->prepare("SELECT stock_quantity FROM raw_materials WHERE id = ?");
                        $s->execute([$side['component_id']]);
                        $stock = floatval($s->fetchColumn());
                    } elseif ($side['component_type'] == 'manufactured') {
                        $s = $this->db->prepare("SELECT stock FROM manufactured_products WHERE id = ?");
                        $s->execute([$side['component_id']]);
                        $stock = floatval($s->fetchColumn());
                    } elseif ($side['component_type'] == 'product') {
                        $subAnalysis = $this->getVirtualStockAnalysis($side['component_id'], $depth + 1);
                        $stock = $subAnalysis['max_produceable'];
                    }

                    $totalSidesAvailability += floor($stock / $effectiveQty);
                }

                // El stock real de contornos es la SUMA de lo que podemos ofrecer 
                // NORMALIZADO por cuántos contornos requiere cada producto.
                $totalProductsBySides = floor($totalSidesAvailability / $maxSides);

                if ($minProduceable === null || $totalProductsBySides < $minProduceable) {
                    // Si los contornos limitan más que la carne, ellos son el cuello de botella
                    if ($totalProductsBySides < ($minProduceable ?? 999999)) {
                        $minProduceable = $totalProductsBySides;
                        $limitingComponent = [
                            'name' => 'Contornos (Opciones agotadas)',
                            'available' => $totalProductsBySides,
                            'unit' => 'porciones',
                            'required_per_unit' => $maxSides
                        ];
                    }
                }
            }
        }

        // 4. ANÁLISIS DE ACOMPAÑANTES (COMPANIONS) - NUEVO
        // Los acompañantes son obligatorios y siempre se agregan 1:1 o según su qty
        $companions = $this->getCompanions($productId);
        if (!empty($companions)) {
            foreach ($companions as $comp) {
                $compQty = floatval($comp['quantity']);
                if ($compQty <= 0)
                    continue;

                $subAnalysis = $this->getVirtualStockAnalysis($comp['companion_id'], $depth + 1);
                $compStock = $subAnalysis['max_produceable'];

                $possibleWithCompanion = floor($compStock / $compQty);

                if ($minProduceable === null || $possibleWithCompanion < $minProduceable) {
                    $minProduceable = $possibleWithCompanion;
                    $limitingComponent = [
                        'name' => 'Acompañante: ' . ($comp['name'] ?? 'Ref.'),
                        'available' => $compStock,
                        'unit' => 'und',
                        'required_per_unit' => $compQty
                    ];
                }
            }
        }

        return [
            'max_produceable' => ($minProduceable === null) ? 0 : $minProduceable,
            'limiting_component' => $limitingComponent
        ];
    }

    // =========================================================
    // GESTIÓN DE EXTRAS VÁLIDOS (CONFIGURACIÓN)
    // =========================================================

    public function getValidExtras($productId)
    {
        $sql = "SELECT pve.*, 
                    CASE 
                        WHEN pve.component_type = 'raw' THEN rm.name
                        WHEN pve.component_type = 'manufactured' THEN mp.name
                        WHEN pve.component_type = 'product' THEN p.name
                    END as name,
                    CASE 
                        WHEN pve.component_type = 'raw' THEN rm.cost_per_unit
                        WHEN pve.component_type = 'manufactured' THEN mp.unit_cost_average
                        WHEN pve.component_type = 'product' THEN p.price_usd
                    END as cost_per_unit
                FROM product_valid_extras pve
                LEFT JOIN raw_materials rm ON pve.component_id = rm.id AND pve.component_type = 'raw'
                LEFT JOIN manufactured_products mp ON pve.component_id = mp.id AND pve.component_type = 'manufactured'
                LEFT JOIN products p ON pve.component_id = p.id AND pve.component_type = 'product'
                WHERE pve.product_id = ?
                ORDER BY pve.is_default DESC, name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$productId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addValidExtra($productId, $componentId, $priceOverride = null, $qtyRequired = 1.00, $componentType = 'raw')
    {
        $check = $this->db->prepare("SELECT id FROM product_valid_extras WHERE product_id = ? AND component_id = ? AND component_type = ?");
        $check->execute([$productId, $componentId, $componentType]);

        if ($check->fetch()) {
            $sql = "UPDATE product_valid_extras SET price_override = ?, quantity_required = ? WHERE product_id = ? AND component_id = ? AND component_type = ?";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$priceOverride, $qtyRequired, $productId, $componentId, $componentType]);
        } else {
            $sql = "INSERT INTO product_valid_extras (product_id, component_type, component_id, price_override, quantity_required) VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$productId, $componentType, $componentId, $priceOverride, $qtyRequired]);
        }
    }

    public function getCompanions($productId)
    {
        $sql = "SELECT pc.*, p.name, p.price_usd as base_price
                FROM product_companions pc
                JOIN products p ON pc.companion_id = p.id
                WHERE pc.product_id = ?
                ORDER BY pc.is_default DESC, p.name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$productId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addCompanion($productId, $companionId, $qty = 1.00, $price = null)
    {
        // Check if exists
        $check = $this->db->prepare("SELECT id FROM product_companions WHERE product_id = ? AND companion_id = ?");
        $check->execute([$productId, $companionId]);
        if ($check->fetch()) {
            return $this->updateCompanion($productId, $companionId, $qty, $price);
        }

        $sql = "INSERT INTO product_companions (product_id, companion_id, quantity, price_override) VALUES (?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$productId, $companionId, $qty, $price]);
    }

    public function removeCompanion($rowId)
    {
        $stmt = $this->db->prepare("DELETE FROM product_companions WHERE id = ?");
        return $stmt->execute([$rowId]);
    }

    public function updateCompanion($productId, $companionId, $qty, $price)
    {
        $sql = "UPDATE product_companions SET quantity = ?, price_override = ? WHERE product_id = ? AND companion_id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$qty, $price, $productId, $companionId]);
    }

    // NUEVO: Obtener receta personalizada de un acompañante
    public function getCompanionRecipe($companionRowId)
    {
        // 1. Buscar si tiene receta personalizada
        $sql = "SELECT pcc.*, 
                CASE
                    WHEN pcc.component_type = 'raw' THEN rm.name
                    WHEN pcc.component_type = 'manufactured' THEN mp.name
                    WHEN pcc.component_type = 'product' THEN p.name
                END as item_name,
                CASE
                    WHEN pcc.component_type = 'raw' THEN rm.unit
                    WHEN pcc.component_type = 'manufactured' THEN mp.unit
                    WHEN pcc.component_type = 'product' THEN 'und'
                END as item_unit
                FROM product_companion_components pcc
                LEFT JOIN raw_materials rm ON pcc.component_id = rm.id AND pcc.component_type = 'raw'
                LEFT JOIN manufactured_products mp ON pcc.component_id = mp.id AND pcc.component_type = 'manufactured'
                LEFT JOIN products p ON pcc.component_id = p.id AND pcc.component_type = 'product'
                WHERE pcc.product_companion_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$companionRowId]);
        $customRecipe = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($customRecipe)) {
            return ['type' => 'custom', 'components' => $customRecipe];
        }

        // 2. Si no, obtener la receta original del producto acompañante
        // Primero necesitamos saber el ID del producto real
        $stmtInfo = $this->db->prepare("SELECT companion_id FROM product_companions WHERE id = ?");
        $stmtInfo->execute([$companionRowId]);
        $companionId = $stmtInfo->fetchColumn();

        if (!$companionId)
            return ['type' => 'original', 'components' => []];

        $originalComponents = $this->getProductComponents($companionId);
        return ['type' => 'original', 'components' => $originalComponents];
    }

    // NUEVO: Guardar receta personalizada
    public function updateCompanionRecipe($companionRowId, $components)
    {
        try {
            $this->db->beginTransaction();

            // 1. Borrar configuración anterior
            $stmtDel = $this->db->prepare("DELETE FROM product_companion_components WHERE product_companion_id = ?");
            $stmtDel->execute([$companionRowId]);

            // 2. Insertar nuevos componentes (si hay)
            if (!empty($components)) {
                $stmtIns = $this->db->prepare("INSERT INTO product_companion_components (product_companion_id, component_type, component_id, quantity) VALUES (?, ?, ?, ?)");
                foreach ($components as $comp) {
                    $stmtIns->execute([
                        $companionRowId,
                        $comp['type'],
                        $comp['id'],
                        $comp['qty']
                    ]);
                }
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }

    public function updateValidExtraQuantity($rowId, $priceOverride, $qtyRequired)
    {
        $stmt = $this->db->prepare("UPDATE product_valid_extras SET price_override = ?, quantity_required = ? WHERE id = ?");
        return $stmt->execute([$priceOverride, $qtyRequired, $rowId]);
    }

    public function removeValidExtra($extraId)
    {
        $stmt = $this->db->prepare("DELETE FROM product_valid_extras WHERE id = ?");
        return $stmt->execute([$extraId]);
    }

    // =========================================================
    // GESTIÓN DE CONTORNOS VÁLIDOS (OPCIONES)
    // =========================================================

    public function getValidSides($productId)
    {
        $sql = "SELECT pvs.*,
                CASE
                    WHEN pvs.component_type = 'raw' THEN rm.name
                    WHEN pvs.component_type = 'manufactured' THEN mp.name
                    WHEN pvs.component_type = 'product' THEN p.name
                END as item_name,
                CASE
                    WHEN pvs.component_type = 'raw' THEN rm.unit
                    WHEN pvs.component_type = 'manufactured' THEN mp.unit
                    WHEN pvs.component_type = 'product' THEN 'und'
                END as item_unit,
                CASE
                    WHEN pvs.component_type = 'raw' THEN rm.cost_per_unit
                    WHEN pvs.component_type = 'manufactured' THEN mp.unit_cost_average
                    WHEN pvs.component_type = 'product' THEN p.price_usd
                END as item_cost
                FROM product_valid_sides pvs
                LEFT JOIN raw_materials rm ON pvs.component_id = rm.id AND pvs.component_type = 'raw'
                LEFT JOIN manufactured_products mp ON pvs.component_id = mp.id AND pvs.component_type = 'manufactured'
                LEFT JOIN products p ON pvs.component_id = p.id AND pvs.component_type = 'product'
                WHERE pvs.product_id = ?
                ORDER BY pvs.is_default DESC, item_name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$productId]);
        $sides = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Si el componente es otro PRODUCTO, calcular su costo real recursivamente
        foreach ($sides as &$side) {
            if ($side['component_type'] === 'product') {
                $side['item_cost'] = $this->calculateProductCost($side['component_id'], 1);
            }
        }

        return $sides;
    }

    public function addValidSide($productId, $type, $componentId, $qty, $priceOverride = 0)
    {
        $sql = "INSERT INTO product_valid_sides (product_id, component_type, component_id, quantity, price_override) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$productId, $type, $componentId, $qty, $priceOverride]);
    }

    public function updateValidSide($sideId, $qty, $priceOverride)
    {
        $stmt = $this->db->prepare("UPDATE product_valid_sides SET quantity = ?, price_override = ? WHERE id = ?");
        return $stmt->execute([$qty, $priceOverride, $sideId]);
    }

    public function removeValidSide($sideId)
    {
        $stmt = $this->db->prepare("DELETE FROM product_valid_sides WHERE id = ?");
        return $stmt->execute([$sideId]);
    }

    public function updateMaxSides($productId, $maxSides)
    {
        $stmt = $this->db->prepare("UPDATE products SET max_sides = ? WHERE id = ?");
        return $stmt->execute([$maxSides, $productId]);
    }

    public function updateContourLogic($productId, $logicType)
    {
        $stmt = $this->db->prepare("UPDATE products SET contour_logic_type = ? WHERE id = ?");
        return $stmt->execute([$logicType, $productId]);
    }

    // =========================================================
    // DUPLICACIÓN DE PRODUCTOS
    // =========================================================

    public function duplicateProduct($productId)
    {
        try {
            $this->db->beginTransaction();
            $original = $this->getProductById($productId);
            if (!$original)
                throw new Exception("Producto no encontrado");

            $newName = $original['name'] . " (Copia)";
            $sql = "INSERT INTO products (name, description, price_usd, price_ves, stock, image_url, profit_margin, product_type, max_sides, contour_logic_type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $newName,
                $original['description'],
                $original['price_usd'],
                $original['price_ves'],
                $original['stock'],
                $original['image_url'],
                $original['profit_margin'],
                $original['product_type'],
                $original['max_sides'] ?? 0,
                $original['contour_logic_type'] ?? 'standard'
            ]);
            $newId = $this->db->lastInsertId();

            $stmtComps = $this->db->prepare("SELECT * FROM product_components WHERE product_id = ?");
            $stmtComps->execute([$productId]);
            foreach ($stmtComps->fetchAll(PDO::FETCH_ASSOC) as $comp) {
                $this->db->prepare("INSERT INTO product_components (product_id, component_type, component_id, quantity) VALUES (?, ?, ?, ?)")->execute([$newId, $comp['component_type'], $comp['component_id'], $comp['quantity']]);
            }

            $stmtExtras = $this->db->prepare("SELECT * FROM product_valid_extras WHERE product_id = ?");
            $stmtExtras->execute([$productId]);
            foreach ($stmtExtras->fetchAll(PDO::FETCH_ASSOC) as $e) {
                $this->db->prepare("INSERT INTO product_valid_extras (product_id, component_type, component_id, price_override, quantity_required, is_default) VALUES (?, ?, ?, ?, ?, ?)")->execute([$newId, $e['component_type'], $e['component_id'], $e['price_override'], $e['quantity_required'], $e['is_default']]);
            }

            $stmtSides = $this->db->prepare("SELECT * FROM product_valid_sides WHERE product_id = ?");
            $stmtSides->execute([$productId]);
            foreach ($stmtSides->fetchAll(PDO::FETCH_ASSOC) as $s) {
                $this->db->prepare("INSERT INTO product_valid_sides (product_id, component_type, component_id, quantity, price_override, is_default) VALUES (?, ?, ?, ?, ?, ?)")->execute([$newId, $s['component_type'], $s['component_id'], $s['quantity'], $s['price_override'], $s['is_default']]);
            }

            // Duplicar Empaque (Packaging)
            $stmtPack = $this->db->prepare("SELECT * FROM product_packaging WHERE product_id = ?");
            $stmtPack->execute([$productId]);
            foreach ($stmtPack->fetchAll(PDO::FETCH_ASSOC) as $p) {
                $this->db->prepare("INSERT INTO product_packaging (product_id, raw_material_id, quantity) VALUES (?, ?, ?)")->execute([$newId, $p['raw_material_id'], $p['quantity']]);
            }

            $this->db->commit();
            return $newId;
        } catch (Exception $e) {
            if ($this->db->inTransaction())
                $this->db->rollBack();
            return false;
        }
    }

    // =========================================================
    // GESTIÓN DE EMPAQUES (PACKAGING)
    // =========================================================

    public function getProductPackaging($productId)
    {
        $sql = "SELECT pp.*, rm.name, rm.unit, rm.cost_per_unit
                FROM product_packaging pp
                JOIN raw_materials rm ON pp.raw_material_id = rm.id
                WHERE pp.product_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$productId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addProductPackaging($productId, $rawMaterialId, $qty)
    {
        $check = $this->db->prepare("SELECT id FROM product_packaging WHERE product_id = ? AND raw_material_id = ?");
        $check->execute([$productId, $rawMaterialId]);

        if ($check->fetch()) {
            $stmt = $this->db->prepare("UPDATE product_packaging SET quantity = quantity + ? WHERE product_id = ? AND raw_material_id = ?");
            return $stmt->execute([$qty, $productId, $rawMaterialId]);
        } else {
            $stmt = $this->db->prepare("INSERT INTO product_packaging (product_id, raw_material_id, quantity) VALUES (?, ?, ?)");
            return $stmt->execute([$productId, $rawMaterialId, $qty]);
        }
    }

    public function updateProductPackaging($packagingId, $qty)
    {
        $stmt = $this->db->prepare("UPDATE product_packaging SET quantity = ? WHERE id = ?");
        return $stmt->execute([$qty, $packagingId]);
    }

    public function removeProductPackaging($packagingId)
    {
        $stmt = $this->db->prepare("DELETE FROM product_packaging WHERE id = ?");
        return $stmt->execute([$packagingId]);
    }

    // =========================================================
    // COPIADO DE CONFIGURACIÓN ENTRE PRODUCTOS
    // =========================================================

    public function copyComponents($fromId, $toId)
    {
        $stmt = $this->db->prepare("SELECT * FROM product_components WHERE product_id = ?");
        $stmt->execute([$fromId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($items as $item) {
            $this->addComponent($toId, $item['component_type'], $item['component_id'], $item['quantity']);
        }
        return true;
    }

    public function copyExtras($fromId, $toId)
    {
        $stmt = $this->db->prepare("SELECT * FROM product_valid_extras WHERE product_id = ?");
        $stmt->execute([$fromId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($items as $item) {
            $this->addValidExtra($toId, $item['component_id'], $item['price_override'], $item['quantity_required'], $item['component_type']);
        }
        return true;
    }

    public function copySides($fromId, $toId)
    {
        $stmt = $this->db->prepare("SELECT * FROM product_valid_sides WHERE product_id = ?");
        $stmt->execute([$fromId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($items as $item) {
            $check = $this->db->prepare("SELECT id FROM product_valid_sides WHERE product_id = ? AND component_type = ? AND component_id = ?");
            $check->execute([$toId, $item['component_type'], $item['component_id']]);
            $existing = $check->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                $this->updateValidSide($existing['id'], $item['quantity'], $item['price_override']);
            } else {
                $this->addValidSide($toId, $item['component_type'], $item['component_id'], $item['quantity'], $item['price_override']);
            }
        }
        return true;
    }

    public function copyPackaging($fromId, $toId)
    {
        $stmt = $this->db->prepare("SELECT * FROM product_packaging WHERE product_id = ?");
        $stmt->execute([$fromId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($items as $item) {
            $this->addProductPackaging($toId, $item['raw_material_id'], $item['quantity']);
        }
        return true;
    }

    public function copyCompanions($fromId, $toId)
    {
        $stmt = $this->db->prepare("SELECT * FROM product_companions WHERE product_id = ?");
        $stmt->execute([$fromId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($items as $item) {
            // 1. Insert or Update companion link
            // Nota: addCompanion verifica si existe y hace update, pero no retorna el ID si hace update.
            // Para garantizar copia de receta custom, es mejor manejarlo manualmente aquí o asegurar que addCompanion retorne ID.

            // Verificamos si ya existe en destino
            $check = $this->db->prepare("SELECT id FROM product_companions WHERE product_id = ? AND companion_id = ?");
            $check->execute([$toId, $item['companion_id']]);
            $existingId = $check->fetchColumn();

            if ($existingId) {
                // Actualizamos
                $this->updateCompanion($toId, $item['companion_id'], $item['quantity'], $item['price_override']);
                $newCompanionRowId = $existingId;
            } else {
                // Insertamos
                $stmtIns = $this->db->prepare("INSERT INTO product_companions (product_id, companion_id, quantity, price_override, is_default) VALUES (?, ?, ?, ?, ?)");
                $stmtIns->execute([$toId, $item['companion_id'], $item['quantity'], $item['price_override'], $item['is_default']]);
                $newCompanionRowId = $this->db->lastInsertId();
            }

            // 2. Copiar receta personalizada si existe en el origen
            $stmtRecipe = $this->db->prepare("SELECT * FROM product_companion_components WHERE product_companion_id = ?");
            $stmtRecipe->execute([$item['id']]); // ID original
            $customComponents = $stmtRecipe->fetchAll(PDO::FETCH_ASSOC);

            if (!empty($customComponents)) {
                // A. Limpiar receta previa en destino (si estamos sobreescribiendo)
                $this->db->prepare("DELETE FROM product_companion_components WHERE product_companion_id = ?")->execute([$newCompanionRowId]);

                // B. Insertar receta copiada
                $stmtInsRecipe = $this->db->prepare("INSERT INTO product_companion_components (product_companion_id, component_type, component_id, quantity) VALUES (?, ?, ?, ?)");
                foreach ($customComponents as $cc) {
                    $stmtInsRecipe->execute([
                        $newCompanionRowId,
                        $cc['component_type'],
                        $cc['component_id'],
                        $cc['quantity']
                    ]);
                }
            }
        }
        return true;
    }

    // =========================================================
    // OPCIONES POR DEFECTO
    // =========================================================

    public function getProductExplodedDefaults($productId)
    {
        $stmt = $this->db->prepare("
            SELECT pdm.*,
                CASE 
                    WHEN pdm.component_type = 'raw' OR pdm.component_type IS NULL THEN rm.name
                    WHEN pdm.component_type = 'manufactured' THEN mp.name
                    WHEN pdm.component_type = 'product' THEN p.name
                END as item_name
            FROM product_default_modifiers pdm
            LEFT JOIN raw_materials rm ON pdm.component_id = rm.id AND (pdm.component_type = 'raw' OR pdm.component_type IS NULL)
            LEFT JOIN manufactured_products mp ON pdm.component_id = mp.id AND pdm.component_type = 'manufactured'
            LEFT JOIN products p ON pdm.component_id = p.id AND pdm.component_type = 'product'
            WHERE pdm.product_id = ?
            ORDER BY pdm.sub_item_index ASC
        ");
        $stmt->execute([$productId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function saveProductExplodedDefaults($productId, $data)
    {
        try {
            $this->db->beginTransaction();

            // 1. Limpiar anteriores
            $this->db->prepare("DELETE FROM product_default_modifiers WHERE product_id = ?")->execute([$productId]);

            // 2. Guardar Nota General si la hay (index -1)
            if (!empty($data['general_note'])) {
                $stmt = $this->db->prepare("INSERT INTO product_default_modifiers (product_id, modifier_type, sub_item_index, note) VALUES (?, 'info', -1, ?)");
                $stmt->execute([$productId, $data['general_note']]);
            }

            // 3. Guardar por ítem
            if (isset($data['items']) && is_array($data['items'])) {
                foreach ($data['items'] as $subItem) {
                    $idx = $subItem['index'];
                    $isTakeaway = ($subItem['consumption'] === 'takeaway') ? 1 : 0;

                    // Fila de estado (Llevar/Mesa)
                    $this->db->prepare("INSERT INTO product_default_modifiers (product_id, modifier_type, sub_item_index, is_takeaway) VALUES (?, 'info', ?, ?)")
                        ->execute([$productId, $idx, $isTakeaway]);

                    // Remociones
                    if (!empty($subItem['remove'])) {
                        $stmtRem = $this->db->prepare("INSERT INTO product_default_modifiers (product_id, modifier_type, sub_item_index, component_id, component_type) VALUES (?, 'remove', ?, ?, 'raw')");
                        foreach ($subItem['remove'] as $rawId) {
                            $stmtRem->execute([$productId, $idx, $rawId]);
                        }
                    }

                    // Adiciones
                    if (!empty($subItem['add'])) {
                        $stmtAdd = $this->db->prepare("INSERT INTO product_default_modifiers (product_id, modifier_type, sub_item_index, component_id, component_type, quantity_adjustment, price_adjustment) VALUES (?, 'add', ?, ?, ?, ?, ?)");
                        foreach ($subItem['add'] as $extra) {
                            $stmtAdd->execute([$productId, $idx, $extra['id'], $extra['type'] ?? 'raw', $extra['qty'] ?? 1.0, $extra['price'] ?? 0]);
                        }
                    }

                    // Contornos
                    if (!empty($subItem['sides'])) {
                        $stmtSide = $this->db->prepare("INSERT INTO product_default_modifiers (product_id, modifier_type, sub_item_index, component_type, component_id, quantity_adjustment, price_adjustment) VALUES (?, 'side', ?, ?, ?, ?, ?)");
                        foreach ($subItem['sides'] as $side) {
                            $stmtSide->execute([$productId, $idx, $side['type'], $side['id'], $side['qty'], $side['price'] ?? 0]);
                        }
                    }
                }
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            if ($this->db->inTransaction())
                $this->db->rollBack();
            throw $e;
        }
    }

    // --- SISTEMA DE CATEGORÍAS ---

    public function getCategories($onlyVisible = false)
    {
        $sql = "SELECT * FROM categories";
        if ($onlyVisible) {
            $sql .= " WHERE is_visible = 1";
        }
        $sql .= " ORDER BY name ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function createCategory($name, $station = 'kitchen', $icon = 'fa-tag', $description = '', $is_visible = 1)
    {
        $stmt = $this->db->prepare("INSERT INTO categories (name, kitchen_station, icon, description, is_visible) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$name, $station, $icon, $description, $is_visible]);
    }

    public function updateCategory($id, $name, $station, $icon, $description, $is_visible = 1)
    {
        $stmt = $this->db->prepare("UPDATE categories SET name = ?, kitchen_station = ?, icon = ?, description = ?, is_visible = ? WHERE id = ?");
        return $stmt->execute([$name, $station, $icon, $description, $is_visible, $id]);
    }

    public function deleteCategory($id)
    {
        $stmt = $this->db->prepare("DELETE FROM categories WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getCategoryById($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>